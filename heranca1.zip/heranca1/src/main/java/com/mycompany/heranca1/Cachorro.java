
package com.mycompany.heranca1;

public class Cachorro extends Animal {
    String raca;
    
    
    @Override
     public void imprimir (){
        System.out.println("Cachorro");
        super.imprimir();
        System.out.println("Raca: " + getRaca());
    }
    public Cachorro(){
        super();
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }
    
}
