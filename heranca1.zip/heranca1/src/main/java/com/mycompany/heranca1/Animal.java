
package com.mycompany.heranca1;


public class Animal {
    String nome;
    double peso;
    
    public void imprimir (){
        System.out.println("Nome: " + getNome());
        System.out.println("Peso: " + getPeso());
        
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }
    
}
