
package com.mycompany.heranca1;


public class Peixe extends Animal {
    String habitat;
    
    /**
     *
     */
    @Override
    public void imprimir (){
        System.out.println("Peixe");
        super.imprimir();
        System.out.println("Tipo habitat: " + getHabitat());
    }
    public Peixe(){
        super();
    }

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }
    
}
