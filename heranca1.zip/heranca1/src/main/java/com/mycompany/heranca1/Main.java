
package com.mycompany.heranca1;
import java.util.Scanner;

public class Main {

    
    public static void main(String[] args) {
        Scanner ler = new Scanner (System.in);
        
        Peixe pex = new Peixe();
        Cachorro cach = new Cachorro();
        
        System.out.println("Digite o nome, peso, e habitat do peixe");
        pex.setNome(ler.next());
        pex.setPeso(ler.nextDouble());
        pex.setHabitat(ler.next());
        
        
        System.out.println("Digite o nome, peso, e a raça do cachorro");
        cach.setNome(ler.next());
        cach.setPeso(ler.nextDouble());
        cach.setRaca(ler.next());
        
        pex.imprimir();
        cach.imprimir();
       
    }
    
}
