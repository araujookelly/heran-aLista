
package com.mycompany.herancapessoa;
import java.util.Scanner;


public class Main {

    public static void main(String[] args) {
        Scanner ler = new Scanner (System.in);
        
        Empregado e = new Empregado();
        Gerente g = new Gerente();
        Vendedor v = new Vendedor();
        Cliente c = new Cliente();
        
      
        System.out.println("Digite o nome do gerente");
        g.setNome(ler.next());
        System.out.println("Digite a idade do gerante");
        g.setIdade(ler.nextInt());
        System.out.println("Digite o sexo do gerente");
        g.setSexo(ler.next());
        System.out.println("Digite a matricula do gerente");
        g.setMatricula(ler.next());
        System.out.println("Digite o salario do gerente");
        g.setSalario(ler.nextDouble());
        System.out.println("Digite o nome da gerencia");
        g.setNomeGerencia(ler.next());
        
        System.out.println("Digite o nome do vendedor");
        v.setNome(ler.next());
        System.out.println("Digite a idade do vendedor");
        v.setIdade(ler.nextInt());
        System.out.println("Digite o sexo do vendedor");
        v.setSexo(ler.next());
        System.out.println("Digite a matricula do do vendedor");
        v.setMatricula(ler.next());
        System.out.println("Digite o salario do vendedor");
        v.setSalario(ler.nextDouble());
        System.out.println("Digite a quantidade de vendas");
        v.setQuantVendas(ler.nextInt());
        System.out.println("Digite o valor das vendas");
        v.setValorVendas(ler.nextDouble());
        
        System.out.println("Digite o nome do cliente");
        c.setNome(ler.next());
        System.out.println("Digite a idade do cliente");
        c.setIdade(ler.nextInt());
        System.out.println("Digite o sexo do cliente");
        c.setSexo(ler.next());
        System.out.println("Digite o ano de nascimento do cliente");
        c.setAnoNas(ler.nextInt());
        System.out.println("Digite o valor da divida do cliente");
        c.setValorDivida(ler.nextDouble());
        
        e.imprimir();
        g.imprimir();
        v.imprimir();
        c.imprimir();
        
        
    }
    
}
