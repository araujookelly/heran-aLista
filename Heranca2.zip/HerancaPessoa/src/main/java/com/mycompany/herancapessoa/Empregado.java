
package com.mycompany.herancapessoa;

public class Empregado extends Pessoa {
    double salario;
    String matricula;
    
    @Override
    public void imprimir (){
        System.out.println("EMPREGADO");
        super.imprimir();
        System.out.println("Salario: " + getSalario());
        System.out.println("Matricula: " + getMatricula());
        
    }
    
    
    public Empregado(){
        super();
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
    
    
    
}
