
package com.mycompany.herancapessoa;

public class Cliente extends Pessoa{
    double valorDivida;
    int anoNas;
    
    @Override
    public void imprimir(){
        System.out.println("CLIENTE");
        super.imprimir();
        System.out.println("Valor da divida:" +getValorDivida());
        System.out.println("Ano nascimento:" +getAnoNas());
    }
    
    public Cliente(){
        super();
    }
    
    
    public double getValorDivida() {
        return valorDivida;
    }

    public void setValorDivida(double valorDivida) {
        this.valorDivida = valorDivida;
    }

    public int getAnoNas() {
        return anoNas;
    }

    public void setAnoNas(int anoNas) {
        this.anoNas = anoNas;
    }
    
}
