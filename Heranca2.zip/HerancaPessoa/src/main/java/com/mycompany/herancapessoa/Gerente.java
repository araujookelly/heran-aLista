
package com.mycompany.herancapessoa;

public class Gerente extends Empregado {
    private String nomeGerencia;
    
    @Override
    public void imprimir(){
        System.out.println("GERENTE");
        super.imprimir();
        System.out.println("Nome gerencia:" + getNomeGerencia());
    }
    
    public Gerente(){
        super();
    }

    public String getNomeGerencia() {
        return nomeGerencia;
    }

    public void setNomeGerencia(String nomeGerencia) {
        this.nomeGerencia = nomeGerencia;
    }
    
    
    
}
