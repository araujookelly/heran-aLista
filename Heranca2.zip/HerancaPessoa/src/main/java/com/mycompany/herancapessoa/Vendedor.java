
package com.mycompany.herancapessoa;

public class Vendedor extends Empregado {
    double valorVendas;
    int quantVendas;
    
    @Override
    public void imprimir(){
        System.out.println("VENDEDOR");
        super.imprimir();
        System.out.println("Valor das Vendas:" +getValorVendas());
        System.out.println("Quantidade de Vendas:" +getQuantVendas());
    }

    
    public Vendedor(){
        super();
       
    }

    public double getValorVendas() {
        return valorVendas;
    }

    public void setValorVendas(double valorVendas) {
        this.valorVendas = valorVendas;
    }

    public int getQuantVendas() {
        return quantVendas;
    }

    public void setQuantVendas(int quantVendas) {
        this.quantVendas = quantVendas;
    }
    
    
    
}
