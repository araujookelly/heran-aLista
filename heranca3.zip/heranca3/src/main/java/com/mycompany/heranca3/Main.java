
package com.mycompany.heranca3;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner ler = new Scanner (System.in);
        
        Pessoa p = new Pessoa();
        Fornecedor f = new Fornecedor();
        Empregado e = new Empregado();
        Operario o = new Operario();
        Vendedor v = new Vendedor();
        
        System.out.println("Digite o nome do Fornecedor");
        f.setNome(ler.nextLine());
        System.out.println("Digite o endereço do Fornecedor");
        f.setEndereco(ler.nextLine());
        System.out.println("Digite o telefone do Fornecedor");
        f.setTelefone(ler.nextLine());
        System.out.println("Digite o valor de credito do Fornecedor");
        f.setValorCredito(ler.nextDouble());
        System.out.println("Digite o valor da divida do Fornecedor");
        f.setValorDivida(ler.nextDouble());
        
        System.out.println("Digite o nome do Operario");
        o.setNome(ler.nextLine());
        System.out.println("Digite o endereço do Operario");
        o.setEndereco(ler.nextLine());
        System.out.println("Digite o telefone do Operario");
        o.setTelefone(ler.nextLine());
        System.out.println("Digite o codigo do setor do operario:");
        o.setCodSetor(ler.nextInt());
        System.out.println("Digite o Salario Base do Operario:");
        o.setSalarioBase(ler.nextDouble());
        System.out.println("Digite o valor do Imposto do salario do Operario:");
        o.setImposto(ler.nextDouble());
        System.out.println("Digite a quantidade Produção mensal do Operario:");
        o.setProducao(ler.nextInt());
        System.out.println("Digite o valor da Comição do Operario:");
        o.setComicao(ler.nextDouble());
        
        System.out.println("Digite o nome do Operario");
        v.setNome(ler.nextLine());
        System.out.println("Digite o endereço do Operario");
        o.setEndereco(ler.nextLine());
        System.out.println("Digite o telefone do Operario");
        v.setTelefone(ler.nextLine());
        System.out.println("Digite o codigo do setor do operario:");
        v.setCodSetor(ler.nextInt());
        System.out.println("Digite o Salario Base do Operario:");
        v.setSalarioBase(ler.nextDouble());
        System.out.println("Digite o valor do Imposto do salario do Operario:");
        v.setImposto(ler.nextDouble());
        System.out.println("Digite a quantidade Produção mensal do Operario:");
        v.setValorVendas(ler.nextInt());
        System.out.println("Digite o valor da Comição do Operario:");
        v.setComicao(ler.nextDouble());
        
        
        f.imprimir();
        o.imprimir();
        v.imprimir();
      
    }
    
}
