
package com.mycompany.heranca3;

public class Operario extends Empregado{
    int producao;
    double comicao;
    
    @Override
    public void imprimir(){
        System.out.println("OPERARIO");
        super.imprimir();
        System.out.println("Valor da Produção:" +getProducao());
        System.out.println("Valor Comição:" +getComicao());
        System.out.println("Salario:" +cSalarioOp());
    }

    public Operario(){
        super();
    }
    @Override
    public double getSalarioBase() {
        return salarioBase;
    }

    @Override
    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }

    @Override
    public double getImposto() {
        return imposto;
    }

    @Override
    public void setImposto(double imposto) {
        this.imposto = imposto;
    }

    
    public int getProducao() {
        return producao;
    }

    public void setProducao(int valorProducao) {
        this.producao = valorProducao;
    }

    public double getComicao() {
        return comicao;
    }

    public void setComicao(double comicao) {
        this.comicao = comicao;
    }
    
    public double cSalarioOp(){
        double salario;
        salario=(salarioBase-imposto)+(producao*comicao);
        return salario;
    }
}
