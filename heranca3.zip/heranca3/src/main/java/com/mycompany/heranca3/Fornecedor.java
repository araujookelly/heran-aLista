
package com.mycompany.heranca3;

public class Fornecedor extends Pessoa{
    double valorCredito;
    double valorDivida;
    
    @Override
    public void imprimir(){
        System.out.println("FORNECEDOR");
        super.imprimir();
        System.out.println("Valor Credito:" +getValorCredito());
        System.out.println("Valor Divida:" +getValorDivida());
        System.out.println("Saldo:" +obterSaldo());
    }

    public Fornecedor(){
        super();
    }
    
    public double getValorCredito() {
        return valorCredito;
    }

    public void setValorCredito(double valorCredito) {
        this.valorCredito = valorCredito;
    }

    public double getValorDivida() {
        return valorDivida;
    }

    public void setValorDivida(double valorDivida) {
        this.valorDivida = valorDivida;
    }
    
    public double obterSaldo(){
        double saldo;
        saldo=valorCredito-valorDivida;
        return saldo;
    }
    
    
}
