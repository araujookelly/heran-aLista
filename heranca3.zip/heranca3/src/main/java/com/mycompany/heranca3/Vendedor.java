
package com.mycompany.heranca3;

public class Vendedor extends Empregado{
    int valorVendas;
    int comicao;
    
    @Override
    public void imprimir(){
        System.out.println("VENDEDOR");
        super.imprimir();
        System.out.println("Valor da Vendas:" +getValorVendas());
        System.out.println("Valor Comição:" +getComicao());
        System.out.println("Salario:" +cSalarioVe());
        
    }
    public Vendedor(){
        super();
    }
    @Override
    public double getSalarioBase() {
        return salarioBase;
    }

    @Override
    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }

    @Override
    public double getImposto() {
        return imposto;
    }

    @Override
    public void setImposto(double imposto) {
        this.imposto = imposto;
    }

    
    public int getValorVendas() {
        return valorVendas;
    }

    public void setValorVendas(int valorVendas) {
        this.valorVendas = valorVendas;
    }

    public int getComicao() {
        return comicao;
    }

    public void setComicao(int comicao) {
        this.comicao = comicao;
    }
    
    public double cSalarioVe(){
        double salario;
        salario=(salarioBase-imposto)+(valorVendas*comicao);
        return salario;
    }
    
}
