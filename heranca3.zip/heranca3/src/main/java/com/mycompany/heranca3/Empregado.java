
package com.mycompany.heranca3;

public class Empregado extends Pessoa {
    int codSetor;
    double salarioBase;
    double imposto;
    
    @Override
    public void imprimir(){
        System.out.println("EMPREGADO");
        super.imprimir();
        System.out.println("Codigo Setor:" +getCodSetor());
        System.out.println("Salario Base:" +getSalarioBase());
        System.out.println("Impostos:" +getImposto());
        System.out.println("Salario:" +calculoSalario());
        
    }
    public Empregado(){
        super();
    }
            
    public int getCodSetor() {
        return codSetor;
    }

    public void setCodSetor(int codSetor) {
        this.codSetor = codSetor;
    }

    public double getSalarioBase() {
        return salarioBase;
    }

    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }

    public double getImposto() {
        return imposto;
    }

    public void setImposto(double impoto) {
        this.imposto = impoto;
    }

    public double calculoSalario(){
        double salario;
        salario=salarioBase-imposto;
        return salario;
    }
    
    
}
